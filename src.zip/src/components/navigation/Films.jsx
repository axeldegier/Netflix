import React from 'react';

const Films = () => {
    return (
        <div className="container">
            <div className="left">
                <h4>Films</h4>
            </div>
            <div className="left">
                <p>filmpjesss</p>
            </div>
        </div>

    )
}


export default Films;