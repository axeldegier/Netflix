import React from 'react';

const Series = () => {
    return (
        <div className="container">
            <div className="left">
                <h4>Series</h4>
            </div>
            <div className="left">
                <p>Seriessss</p>
            </div>
        </div>

    )
}


export default Series;