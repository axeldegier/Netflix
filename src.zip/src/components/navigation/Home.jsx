import React from 'react';

const Home = () => {
    return (
        <div className="container">
            <div className="left">
                <h4>Home</h4>
            </div>
            <div className="left">
                <p>Blalalla</p>
            </div>
        </div>

    )
}


export default Home;