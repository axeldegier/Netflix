import React from 'react';

const MyList = () => {
    return (
        <div className="container">
            <div className="left">
                <h4>MyList</h4>
            </div>
            <div className="left">
                <p>MyList</p>
            </div>
        </div>

    )
}


export default MyList;