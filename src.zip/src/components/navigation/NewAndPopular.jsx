import React from 'react';

const NewAndPopular = () => {
    return (
        <div className="container">
            <div className="left">
                <h4>NewAndPopular</h4>
            </div>
            <div className="left">
                <p>NewAndPopularrrrr</p>
            </div>
        </div>

    )
}


export default NewAndPopular;